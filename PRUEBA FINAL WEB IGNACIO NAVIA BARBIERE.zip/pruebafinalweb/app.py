# app.py
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/ejercicio2', methods=['GET', 'POST'])
def ejercicio2():   
    mensaje = None

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Verificar credenciales
        if username == 'juan' and password == 'admin':
            mensaje = 'Bienvenido administrador juan'
        elif username == 'pepe' and password == 'user':
            mensaje = 'Bienvenido usuario pepe'
        else:
            mensaje = 'Usuario o contraseña incorrectos'

    return render_template('ejercicio2.html', mensaje=mensaje)

@app.route('/ejercicio1', methods=['GET', 'POST'])
def ejercicio1():
    if request.method == 'POST':
        name = request.form.get('name')
        age = int(request.form.get('age'))
        paint_cans = int(request.form.get('paint_cans'))

        paint_can_price = 9000
        total_without_discount = paint_cans * paint_can_price

        if 18 <= age <= 30:
            discount = 0.15
        elif age > 30:
            discount = 0.25
        else:
            discount = 0

        total_with_discount = total_without_discount * (1 - discount)

        return render_template('resultado_ejercicio1.html',
                               name=name,
                               total_without_discount=total_without_discount,
                               discount=discount,
                               total_with_discount=total_with_discount)
    return render_template('ejercicio1.html')
if __name__ == '__main__':
    app.run(debug=True)
